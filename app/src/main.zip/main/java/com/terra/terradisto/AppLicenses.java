package com.terra.terradisto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class AppLicenses {
    public final ArrayList<String> keys = new ArrayList<>();
    public AppLicenses() {
        // PDF의 무료 키 예시 사용
        keys.add("1Xj1z6thybdW/O+Jc6XG2ExVzYuY3GF4h+");
    }
}
