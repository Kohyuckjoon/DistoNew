package com.terra.terradisto;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import ch.leica.sdk.Devices.Device;

/**
 * 목록에 뿌릴 장치 아이템 (SDK Device를 직접 보관)
 */
public class DeviceItem {

    @NonNull public final String name;
    @NonNull public final String address;
    public final boolean connected;

    // 연결/명령에 사용하기 위해 SDK Device를 들고있음
    @Nullable public final transient Device device;

    public DeviceItem(@NonNull String name,
                      @NonNull String address,
                      boolean connected,
                      @Nullable Device device) {
        this.name = (name == null || name.trim().isEmpty()) ? "Unknown" : name;
        this.address = address;
        this.connected = connected;
        this.device = device;
    }

    public DeviceItem withConnected(boolean c) {
        return new DeviceItem(this.name, this.address, c, this.device);
    }
}