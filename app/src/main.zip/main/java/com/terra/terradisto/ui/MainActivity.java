package com.terra.terradisto.ui;

import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.terra.terradisto.R;
import com.terra.terradisto.core.permission.PermissionHelper;
import com.terra.terradisto.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;
    AppBarConfiguration appBarConfiguration;
    NavController navController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // ⬇️ 앱 켜지자마자 권한 체크 & 요청
        if (!PermissionHelper.hasAll(this, PermissionHelper.requiredClassicBtPermissions())) {
            blePermsLauncher.launch(PermissionHelper.requiredClassicBtPermissions());
        }

        setSupportActionBar(binding.toolbar);

        // ✅ 여기! FragmentManager에서 NavHostFragment를 찾아 NavController 얻기
        NavHostFragment navHostFragment =
                (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment);
        navController = navHostFragment.getNavController();
        appBarConfiguration = new AppBarConfiguration.Builder(R.id.mainFragment).build();
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);

    }

    @Override
    public boolean onSupportNavigateUp() {
        return NavigationUI.navigateUp(navController, appBarConfiguration)
                || super.onSupportNavigateUp();
    }

    private final ActivityResultLauncher<String[]> blePermsLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), r -> {
                if (!PermissionHelper.hasAll(this, PermissionHelper.requiredClassicBtPermissions())) {
                    Toast.makeText(this, "권한이 필요합니다.", Toast.LENGTH_SHORT).show();
                }
            });

}