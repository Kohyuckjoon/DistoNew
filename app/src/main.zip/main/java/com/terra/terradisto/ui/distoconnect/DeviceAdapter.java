package com.terra.terradisto.ui.distoconnect;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.terra.terradisto.R;
import com.terra.terradisto.DeviceItem;

public class DeviceAdapter extends ListAdapter<DeviceItem, DeviceAdapter.VH> {

    public interface OnClickConnect {
        void onClick(DeviceItem item);
    }

    private final OnClickConnect connectListener;

    public DeviceAdapter(@NonNull OnClickConnect connectListener) {
        super(DIFF);
        this.connectListener = connectListener;
    }

    private static final DiffUtil.ItemCallback<DeviceItem> DIFF =
            new DiffUtil.ItemCallback<DeviceItem>() {
                @Override
                public boolean areItemsTheSame(@NonNull DeviceItem oldItem, @NonNull DeviceItem newItem) {
                    return oldItem.address.equals(newItem.address);
                }

                @Override
                public boolean areContentsTheSame(@NonNull DeviceItem oldItem, @NonNull DeviceItem newItem) {
                    return oldItem.connected == newItem.connected
                            && oldItem.name.equals(newItem.name);
                }
            };

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_device, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        DeviceItem it = getItem(position);
        h.name.setText(it.name);
        h.addr.setText(it.address);
        h.state.setText(it.connected ? "Connected" : "Disconnected");
        h.btn.setEnabled(it.device != null);
        h.btn.setOnClickListener(v -> {
            if (connectListener != null) connectListener.onClick(it);
        });
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView name, addr, state;
        Button btn;
        VH(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.tvName);
            addr = itemView.findViewById(R.id.tvAddr);
            state = itemView.findViewById(R.id.tvState);
            btn  = itemView.findViewById(R.id.btnConnect);
        }
    }
}
